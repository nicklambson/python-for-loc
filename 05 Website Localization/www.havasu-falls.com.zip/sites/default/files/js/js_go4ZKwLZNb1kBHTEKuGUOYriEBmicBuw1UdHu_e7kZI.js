/**
 * @file
 * Fires counter to log adsense clicks.
 */

(function () {
  var lastStatus = '';

  function adsense_click() {
    window.focus();
    if (window.status && (window.status != lastStatus)) {
      lastStatus = window.status;
      var img = new Image();
      img.src = window.location.protocol + '//' + window.location.host + '/adsense_click' +
        '?u=' + escape(document.location) +
        '&t=' + escape(document.title) +
        '&r=' + escape(document.referrer);
    }
  }

  var iframeObj;
  var elements;
  elements = document.getElementsByTagName("iframe");
  for (var i = 0; i < elements.length; i++) {
    if (elements[i].src.indexOf('googlesyndication.com') > -1) {
      if (document.layers) {
        elements[i].captureEvents(Events.ONFOCUS);
      }
      elements[i].onfocus = adsense_click;
      iframeObj = elements[i];
    }
  }

})(jQuery);
;
/*!
	Colorbox 1.6.1
	license: MIT
	http://www.jacklmoore.com/colorbox
*/
(function(t,e,i){function n(i,n,o){var r=e.createElement(i);return n&&(r.id=Z+n),o&&(r.style.cssText=o),t(r)}function o(){return i.innerHeight?i.innerHeight:t(i).height()}function r(e,i){i!==Object(i)&&(i={}),this.cache={},this.el=e,this.value=function(e){var n;return void 0===this.cache[e]&&(n=t(this.el).attr("data-cbox-"+e),void 0!==n?this.cache[e]=n:void 0!==i[e]?this.cache[e]=i[e]:void 0!==X[e]&&(this.cache[e]=X[e])),this.cache[e]},this.get=function(e){var i=this.value(e);return t.isFunction(i)?i.call(this.el,this):i}}function h(t){var e=W.length,i=(A+t)%e;return 0>i?e+i:i}function a(t,e){return Math.round((/%/.test(t)?("x"===e?E.width():o())/100:1)*parseInt(t,10))}function s(t,e){return t.get("photo")||t.get("photoRegex").test(e)}function l(t,e){return t.get("retinaUrl")&&i.devicePixelRatio>1?e.replace(t.get("photoRegex"),t.get("retinaSuffix")):e}function d(t){"contains"in y[0]&&!y[0].contains(t.target)&&t.target!==v[0]&&(t.stopPropagation(),y.focus())}function c(t){c.str!==t&&(y.add(v).removeClass(c.str).addClass(t),c.str=t)}function g(e){A=0,e&&e!==!1&&"nofollow"!==e?(W=t("."+te).filter(function(){var i=t.data(this,Y),n=new r(this,i);return n.get("rel")===e}),A=W.index(_.el),-1===A&&(W=W.add(_.el),A=W.length-1)):W=t(_.el)}function u(i){t(e).trigger(i),ae.triggerHandler(i)}function f(i){var o;if(!G){if(o=t(i).data(Y),_=new r(i,o),g(_.get("rel")),!$){$=q=!0,c(_.get("className")),y.css({visibility:"hidden",display:"block",opacity:""}),I=n(se,"LoadedContent","width:0; height:0; overflow:hidden; visibility:hidden"),b.css({width:"",height:""}).append(I),j=T.height()+k.height()+b.outerHeight(!0)-b.height(),D=C.width()+H.width()+b.outerWidth(!0)-b.width(),N=I.outerHeight(!0),z=I.outerWidth(!0);var h=a(_.get("initialWidth"),"x"),s=a(_.get("initialHeight"),"y"),l=_.get("maxWidth"),f=_.get("maxHeight");_.w=(l!==!1?Math.min(h,a(l,"x")):h)-z-D,_.h=(f!==!1?Math.min(s,a(f,"y")):s)-N-j,I.css({width:"",height:_.h}),J.position(),u(ee),_.get("onOpen"),O.add(S).hide(),y.focus(),_.get("trapFocus")&&e.addEventListener&&(e.addEventListener("focus",d,!0),ae.one(re,function(){e.removeEventListener("focus",d,!0)})),_.get("returnFocus")&&ae.one(re,function(){t(_.el).focus()})}var p=parseFloat(_.get("opacity"));v.css({opacity:p===p?p:"",cursor:_.get("overlayClose")?"pointer":"",visibility:"visible"}).show(),_.get("closeButton")?B.html(_.get("close")).appendTo(b):B.appendTo("<div/>"),w()}}function p(){y||(V=!1,E=t(i),y=n(se).attr({id:Y,"class":t.support.opacity===!1?Z+"IE":"",role:"dialog",tabindex:"-1"}).hide(),v=n(se,"Overlay").hide(),M=t([n(se,"LoadingOverlay")[0],n(se,"LoadingGraphic")[0]]),x=n(se,"Wrapper"),b=n(se,"Content").append(S=n(se,"Title"),F=n(se,"Current"),P=t('<button type="button"/>').attr({id:Z+"Previous"}),K=t('<button type="button"/>').attr({id:Z+"Next"}),R=n("button","Slideshow"),M),B=t('<button type="button"/>').attr({id:Z+"Close"}),x.append(n(se).append(n(se,"TopLeft"),T=n(se,"TopCenter"),n(se,"TopRight")),n(se,!1,"clear:left").append(C=n(se,"MiddleLeft"),b,H=n(se,"MiddleRight")),n(se,!1,"clear:left").append(n(se,"BottomLeft"),k=n(se,"BottomCenter"),n(se,"BottomRight"))).find("div div").css({"float":"left"}),L=n(se,!1,"position:absolute; width:9999px; visibility:hidden; display:none; max-width:none;"),O=K.add(P).add(F).add(R)),e.body&&!y.parent().length&&t(e.body).append(v,y.append(x,L))}function m(){function i(t){t.which>1||t.shiftKey||t.altKey||t.metaKey||t.ctrlKey||(t.preventDefault(),f(this))}return y?(V||(V=!0,K.click(function(){J.next()}),P.click(function(){J.prev()}),B.click(function(){J.close()}),v.click(function(){_.get("overlayClose")&&J.close()}),t(e).bind("keydown."+Z,function(t){var e=t.keyCode;$&&_.get("escKey")&&27===e&&(t.preventDefault(),J.close()),$&&_.get("arrowKey")&&W[1]&&!t.altKey&&(37===e?(t.preventDefault(),P.click()):39===e&&(t.preventDefault(),K.click()))}),t.isFunction(t.fn.on)?t(e).on("click."+Z,"."+te,i):t("."+te).live("click."+Z,i)),!0):!1}function w(){var e,o,r,h=J.prep,d=++le;if(q=!0,U=!1,u(he),u(ie),_.get("onLoad"),_.h=_.get("height")?a(_.get("height"),"y")-N-j:_.get("innerHeight")&&a(_.get("innerHeight"),"y"),_.w=_.get("width")?a(_.get("width"),"x")-z-D:_.get("innerWidth")&&a(_.get("innerWidth"),"x"),_.mw=_.w,_.mh=_.h,_.get("maxWidth")&&(_.mw=a(_.get("maxWidth"),"x")-z-D,_.mw=_.w&&_.w<_.mw?_.w:_.mw),_.get("maxHeight")&&(_.mh=a(_.get("maxHeight"),"y")-N-j,_.mh=_.h&&_.h<_.mh?_.h:_.mh),e=_.get("href"),Q=setTimeout(function(){M.show()},100),_.get("inline")){var c=t(e);r=t("<div>").hide().insertBefore(c),ae.one(he,function(){r.replaceWith(c)}),h(c)}else _.get("iframe")?h(" "):_.get("html")?h(_.get("html")):s(_,e)?(e=l(_,e),U=_.get("createImg"),t(U).addClass(Z+"Photo").bind("error."+Z,function(){h(n(se,"Error").html(_.get("imgError")))}).one("load",function(){d===le&&setTimeout(function(){var e;_.get("retinaImage")&&i.devicePixelRatio>1&&(U.height=U.height/i.devicePixelRatio,U.width=U.width/i.devicePixelRatio),_.get("scalePhotos")&&(o=function(){U.height-=U.height*e,U.width-=U.width*e},_.mw&&U.width>_.mw&&(e=(U.width-_.mw)/U.width,o()),_.mh&&U.height>_.mh&&(e=(U.height-_.mh)/U.height,o())),_.h&&(U.style.marginTop=Math.max(_.mh-U.height,0)/2+"px"),W[1]&&(_.get("loop")||W[A+1])&&(U.style.cursor="pointer",t(U).bind("click."+Z,function(){J.next()})),U.style.width=U.width+"px",U.style.height=U.height+"px",h(U)},1)}),U.src=e):e&&L.load(e,_.get("data"),function(e,i){d===le&&h("error"===i?n(se,"Error").html(_.get("xhrError")):t(this).contents())})}var v,y,x,b,T,C,H,k,W,E,I,L,M,S,F,R,K,P,B,O,_,j,D,N,z,A,U,$,q,G,Q,J,V,X={html:!1,photo:!1,iframe:!1,inline:!1,transition:"elastic",speed:300,fadeOut:300,width:!1,initialWidth:"600",innerWidth:!1,maxWidth:!1,height:!1,initialHeight:"450",innerHeight:!1,maxHeight:!1,scalePhotos:!0,scrolling:!0,opacity:.9,preloading:!0,className:!1,overlayClose:!0,escKey:!0,arrowKey:!0,top:!1,bottom:!1,left:!1,right:!1,fixed:!1,data:void 0,closeButton:!0,fastIframe:!0,open:!1,reposition:!0,loop:!0,slideshow:!1,slideshowAuto:!0,slideshowSpeed:2500,slideshowStart:"start slideshow",slideshowStop:"stop slideshow",photoRegex:/\.(gif|png|jp(e|g|eg)|bmp|ico|webp|jxr|svg)((#|\?).*)?$/i,retinaImage:!1,retinaUrl:!1,retinaSuffix:"@2x.$1",current:"image {current} of {total}",previous:"previous",next:"next",close:"close",xhrError:"This content failed to load.",imgError:"This image failed to load.",returnFocus:!0,trapFocus:!0,onOpen:!1,onLoad:!1,onComplete:!1,onCleanup:!1,onClosed:!1,rel:function(){return this.rel},href:function(){return t(this).attr("href")},title:function(){return this.title},createImg:function(){var e=new Image,i=t(this).data("cbox-img-attrs");return"object"==typeof i&&t.each(i,function(t,i){e[t]=i}),e},createIframe:function(){var i=e.createElement("iframe"),n=t(this).data("cbox-iframe-attrs");return"object"==typeof n&&t.each(n,function(t,e){i[t]=e}),"frameBorder"in i&&(i.frameBorder=0),"allowTransparency"in i&&(i.allowTransparency="true"),i.name=(new Date).getTime(),i.allowFullScreen=!0,i}},Y="colorbox",Z="cbox",te=Z+"Element",ee=Z+"_open",ie=Z+"_load",ne=Z+"_complete",oe=Z+"_cleanup",re=Z+"_closed",he=Z+"_purge",ae=t("<a/>"),se="div",le=0,de={},ce=function(){function t(){clearTimeout(h)}function e(){(_.get("loop")||W[A+1])&&(t(),h=setTimeout(J.next,_.get("slideshowSpeed")))}function i(){R.html(_.get("slideshowStop")).unbind(s).one(s,n),ae.bind(ne,e).bind(ie,t),y.removeClass(a+"off").addClass(a+"on")}function n(){t(),ae.unbind(ne,e).unbind(ie,t),R.html(_.get("slideshowStart")).unbind(s).one(s,function(){J.next(),i()}),y.removeClass(a+"on").addClass(a+"off")}function o(){r=!1,R.hide(),t(),ae.unbind(ne,e).unbind(ie,t),y.removeClass(a+"off "+a+"on")}var r,h,a=Z+"Slideshow_",s="click."+Z;return function(){r?_.get("slideshow")||(ae.unbind(oe,o),o()):_.get("slideshow")&&W[1]&&(r=!0,ae.one(oe,o),_.get("slideshowAuto")?i():n(),R.show())}}();t[Y]||(t(p),J=t.fn[Y]=t[Y]=function(e,i){var n,o=this;return e=e||{},t.isFunction(o)&&(o=t("<a/>"),e.open=!0),o[0]?(p(),m()&&(i&&(e.onComplete=i),o.each(function(){var i=t.data(this,Y)||{};t.data(this,Y,t.extend(i,e))}).addClass(te),n=new r(o[0],e),n.get("open")&&f(o[0])),o):o},J.position=function(e,i){function n(){T[0].style.width=k[0].style.width=b[0].style.width=parseInt(y[0].style.width,10)-D+"px",b[0].style.height=C[0].style.height=H[0].style.height=parseInt(y[0].style.height,10)-j+"px"}var r,h,s,l=0,d=0,c=y.offset();if(E.unbind("resize."+Z),y.css({top:-9e4,left:-9e4}),h=E.scrollTop(),s=E.scrollLeft(),_.get("fixed")?(c.top-=h,c.left-=s,y.css({position:"fixed"})):(l=h,d=s,y.css({position:"absolute"})),d+=_.get("right")!==!1?Math.max(E.width()-_.w-z-D-a(_.get("right"),"x"),0):_.get("left")!==!1?a(_.get("left"),"x"):Math.round(Math.max(E.width()-_.w-z-D,0)/2),l+=_.get("bottom")!==!1?Math.max(o()-_.h-N-j-a(_.get("bottom"),"y"),0):_.get("top")!==!1?a(_.get("top"),"y"):Math.round(Math.max(o()-_.h-N-j,0)/2),y.css({top:c.top,left:c.left,visibility:"visible"}),x[0].style.width=x[0].style.height="9999px",r={width:_.w+z+D,height:_.h+N+j,top:l,left:d},e){var g=0;t.each(r,function(t){return r[t]!==de[t]?(g=e,void 0):void 0}),e=g}de=r,e||y.css(r),y.dequeue().animate(r,{duration:e||0,complete:function(){n(),q=!1,x[0].style.width=_.w+z+D+"px",x[0].style.height=_.h+N+j+"px",_.get("reposition")&&setTimeout(function(){E.bind("resize."+Z,J.position)},1),t.isFunction(i)&&i()},step:n})},J.resize=function(t){var e;$&&(t=t||{},t.width&&(_.w=a(t.width,"x")-z-D),t.innerWidth&&(_.w=a(t.innerWidth,"x")),I.css({width:_.w}),t.height&&(_.h=a(t.height,"y")-N-j),t.innerHeight&&(_.h=a(t.innerHeight,"y")),t.innerHeight||t.height||(e=I.scrollTop(),I.css({height:"auto"}),_.h=I.height()),I.css({height:_.h}),e&&I.scrollTop(e),J.position("none"===_.get("transition")?0:_.get("speed")))},J.prep=function(i){function o(){return _.w=_.w||I.width(),_.w=_.mw&&_.mw<_.w?_.mw:_.w,_.w}function a(){return _.h=_.h||I.height(),_.h=_.mh&&_.mh<_.h?_.mh:_.h,_.h}if($){var d,g="none"===_.get("transition")?0:_.get("speed");I.remove(),I=n(se,"LoadedContent").append(i),I.hide().appendTo(L.show()).css({width:o(),overflow:_.get("scrolling")?"auto":"hidden"}).css({height:a()}).prependTo(b),L.hide(),t(U).css({"float":"none"}),c(_.get("className")),d=function(){function i(){t.support.opacity===!1&&y[0].style.removeAttribute("filter")}var n,o,a=W.length;$&&(o=function(){clearTimeout(Q),M.hide(),u(ne),_.get("onComplete")},S.html(_.get("title")).show(),I.show(),a>1?("string"==typeof _.get("current")&&F.html(_.get("current").replace("{current}",A+1).replace("{total}",a)).show(),K[_.get("loop")||a-1>A?"show":"hide"]().html(_.get("next")),P[_.get("loop")||A?"show":"hide"]().html(_.get("previous")),ce(),_.get("preloading")&&t.each([h(-1),h(1)],function(){var i,n=W[this],o=new r(n,t.data(n,Y)),h=o.get("href");h&&s(o,h)&&(h=l(o,h),i=e.createElement("img"),i.src=h)})):O.hide(),_.get("iframe")?(n=_.get("createIframe"),_.get("scrolling")||(n.scrolling="no"),t(n).attr({src:_.get("href"),"class":Z+"Iframe"}).one("load",o).appendTo(I),ae.one(he,function(){n.src="//about:blank"}),_.get("fastIframe")&&t(n).trigger("load")):o(),"fade"===_.get("transition")?y.fadeTo(g,1,i):i())},"fade"===_.get("transition")?y.fadeTo(g,0,function(){J.position(0,d)}):J.position(g,d)}},J.next=function(){!q&&W[1]&&(_.get("loop")||W[A+1])&&(A=h(1),f(W[A]))},J.prev=function(){!q&&W[1]&&(_.get("loop")||A)&&(A=h(-1),f(W[A]))},J.close=function(){$&&!G&&(G=!0,$=!1,u(oe),_.get("onCleanup"),E.unbind("."+Z),v.fadeTo(_.get("fadeOut")||0,0),y.stop().fadeTo(_.get("fadeOut")||0,0,function(){y.hide(),v.hide(),u(he),I.remove(),setTimeout(function(){G=!1,u(re),_.get("onClosed")},1)}))},J.remove=function(){y&&(y.stop(),t[Y].close(),y.stop(!1,!0).remove(),v.remove(),G=!1,y=null,t("."+te).removeData(Y).removeClass(te),t(e).unbind("click."+Z).unbind("keydown."+Z))},J.element=function(){return t(_.el)},J.settings=X)})(jQuery,document,window);;
/**
 * @file
 * Colorbox module init js.
 */

(function ($) {

Drupal.behaviors.initColorbox = {
  attach: function (context, settings) {
    if (!$.isFunction($.colorbox) || typeof settings.colorbox === 'undefined') {
      return;
    }

    if (settings.colorbox.mobiledetect && window.matchMedia) {
      // Disable Colorbox for small screens.
      var mq = window.matchMedia("(max-device-width: " + settings.colorbox.mobiledevicewidth + ")");
      if (mq.matches) {
        return;
      }
    }

    // Use "data-colorbox-gallery" if set otherwise use "rel".
    settings.colorbox.rel = function () {
      if ($(this).data('colorbox-gallery')) {
        return $(this).data('colorbox-gallery');
      }
      else {
        return $(this).attr('rel');
      }
    };

    $('.colorbox', context)
      .once('init-colorbox')
      .colorbox(settings.colorbox);

    $(context).bind('cbox_complete', function () {
      Drupal.attachBehaviors('#cboxLoadedContent');
    });
  }
};

})(jQuery);
;
/**
 * @file
 * Colorbox module style js.
 */

(function ($) {

Drupal.behaviors.initColorboxDefaultStyle = {
  attach: function (context, settings) {
    $(context).bind('cbox_complete', function () {
      // Only run if there is a title.
      if ($('#cboxTitle:empty', context).length == false) {
        $('#cboxLoadedContent img', context).bind('mouseover', function () {
          $('#cboxTitle', context).slideDown();
        });
        $('#cboxOverlay', context).bind('mouseover', function () {
          $('#cboxTitle', context).slideUp();
        });
      }
      else {
        $('#cboxTitle', context).hide();
      }
    });
  }
};

})(jQuery);
;
/**
 * @file
 * Colorbox module load js.
 */
(function ($) {

Drupal.behaviors.initColorboxLoad = {
  attach: function (context, settings) {
    if (!$.isFunction($.colorbox) || typeof settings.colorbox === 'undefined') {
      return;
    }

    if (settings.colorbox.mobiledetect && window.matchMedia) {
      // Disable Colorbox for small screens.
      var mq = window.matchMedia("(max-device-width: " + settings.colorbox.mobiledevicewidth + ")");
      if (mq.matches) {
        return;
      }
    }

    $.urlParams = function (url) {
      var p = {},
          e,
          a = /\+/g,  // Regex for replacing addition symbol with a space.
          r = /([^&=]+)=?([^&]*)/g,
          d = function (s) { return decodeURIComponent(s.replace(a, ' ')); },
          q = url.split('?');
      while (e = r.exec(q[1])) {
        e[1] = d(e[1]);
        e[2] = d(e[2]);
        switch (e[2].toLowerCase()) {
          case 'true':
          case 'yes':
            e[2] = true;
            break;
          case 'false':
          case 'no':
            e[2] = false;
            break;
        }
        if (e[1] == 'width') { e[1] = 'innerWidth'; }
        if (e[1] == 'height') { e[1] = 'innerHeight'; }
        p[e[1]] = e[2];
      }
      return p;
    };
    $('.colorbox-load', context)
      .once('init-colorbox-load', function () {
        var params = $.urlParams($(this).attr('href'));
        $(this).colorbox($.extend({}, settings.colorbox, params));
      });
  }
};

})(jQuery);
;
/**
 * @file
 * Colorbox module inline js.
 */

(function ($) {

Drupal.behaviors.initColorboxInline = {
  attach: function (context, settings) {
    if (!$.isFunction($.colorbox) || typeof settings.colorbox === 'undefined') {
      return;
    }

    if (settings.colorbox.mobiledetect && window.matchMedia) {
      // Disable Colorbox for small screens.
      var mq = window.matchMedia("(max-device-width: " + settings.colorbox.mobiledevicewidth + ")");
      if (mq.matches) {
        return;
      }
    }

    $.urlParam = function(name, url){
      if (name == 'fragment') {
        var results = new RegExp('(#[^&#]*)').exec(url);
      }
      else {
        var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(url);
      }
      if (!results) { return ''; }
      return results[1] || '';
    };
    $('.colorbox-inline', context).once('init-colorbox-inline').colorbox({
      transition:settings.colorbox.transition,
      speed:settings.colorbox.speed,
      opacity:settings.colorbox.opacity,
      slideshow:settings.colorbox.slideshow,
      slideshowAuto:settings.colorbox.slideshowAuto,
      slideshowSpeed:settings.colorbox.slideshowSpeed,
      slideshowStart:settings.colorbox.slideshowStart,
      slideshowStop:settings.colorbox.slideshowStop,
      current:settings.colorbox.current,
      previous:settings.colorbox.previous,
      next:settings.colorbox.next,
      close:settings.colorbox.close,
      overlayClose:settings.colorbox.overlayClose,
      maxWidth:settings.colorbox.maxWidth,
      maxHeight:settings.colorbox.maxHeight,
      innerWidth:function(){
        return $.urlParam('width', $(this).attr('href'));
      },
      innerHeight:function(){
        return $.urlParam('height', $(this).attr('href'));
      },
      title:function(){
        return decodeURIComponent($.urlParam('title', $(this).attr('href')));
      },
      iframe:function(){
        return $.urlParam('iframe', $(this).attr('href'));
      },
      inline:function(){
        return $.urlParam('inline', $(this).attr('href'));
      },
      href:function(){
        return $.urlParam('fragment', $(this).attr('href'));
      }
    });
  }
};

})(jQuery);
;
jQuery(document).ready(function($){
    // console.log('survey-form');
    $('#edit-button-prev').hide();
     $('#edit-survey-save').hide();

	 
	 function surveryButtonNext(obj){
		 // alert(obj);
		 // return false;
            $('#edit-survey-save').hide();
            $('.multipage-panes .messages').remove();
            $('.multipage-panes').append('<div class="messages"></div>');
            $('.multipage-panes .messages').hide()

            var currentElem = $(obj).parents('form').find('.multipage-panes .current');
            var isCheckedLen =  currentElem.find("input:checked").length;

            if (isCheckedLen == 0){
                $('.multipage-panes .messages').show().addClass('error');
                $('.multipage-panes .messages').text('Please checked an option to proceed.');
                return;
            }

            var nextElem = currentElem.next();

            var currentElemClass = currentElem.attr('class');
            var nextElemClass = nextElem.attr('class');
            var nextElemFormItemClass = nextElem.find('.form-type-radios').attr('class');

            if (nextElemClass != undefined) {
                $('#edit-button-prev').show();
                currentElem.hide().removeClass('current');
                nextElem.show().addClass('current');
            }

            if (nextElem.hasClass('last')) {
                $('#edit-button-next').hide();
                $('#edit-survey-save').show();
            }		 
	 }
	 
    // edit subscription

    $("body" ).delegate( "#edit-button-next", "click", function(e) {
            $('#edit-survey-save').hide();
            $('.multipage-panes .messages').remove();
            $('.multipage-panes').append('<div class="messages"></div>');
            $('.multipage-panes .messages').hide()

            var currentElem = $(this).parents('form').find('.multipage-panes .current');
            var isCheckedLen =  currentElem.find("input:checked").length;

            if (isCheckedLen == 0){
                $('.multipage-panes .messages').show().addClass('error');
                $('.multipage-panes .messages').text('Please choose an option to proceed.');
                return false;
            }

            var nextElem = currentElem.next();

            var currentElemClass = currentElem.attr('class');
            var nextElemClass = nextElem.attr('class');
            var nextElemFormItemClass = nextElem.find('.form-type-radios').attr('class');

            if (nextElemClass != undefined) {
                $('#edit-button-prev').show();
                currentElem.hide().removeClass('current');
                nextElem.show().addClass('current');
            }

            if (nextElem.hasClass('last')) {
                $('#edit-button-next').hide();
                $('#edit-survey-save').show();
            }
    });


    $("body" ).delegate( "#edit-button-prev", "click", function(e) {
        $('#edit-survey-save').hide();
        $('#edit-button-prev').show();
        $('#edit-button-next').show();

        var currentElem = $(this).parents('form').find('.multipage-panes .current');
        var prevElem = currentElem.prev();

        var currentElemClass = currentElem.attr('class');
        var prevElemClass = prevElem.attr('class');
        var prevElemFormItemClass = prevElem.find('.form-type-radios').attr('class');

        if (prevElemClass != undefined) {
            $('#edit-button-prev').show();
            $('#edit-button-next').show();
            $('#edit-survey-save').hide();
            currentElem.hide().removeClass('current');
            prevElem.show().addClass('current');
        }

        if (prevElem.hasClass('first')) {
            $('#edit-button-prev').hide();
            $('#edit-button-next').show();
            $('#edit-survey-save').hide();
        }
    });


	if ( ('#guru-tools-survey-form').length ){
/* 		$('#guru-tools-survey-form #edit-survey-save').click(function(e) {
			e.preventDefault();
			var trip_seasons = $('#edit-trip-seasons input:checked').val();
			var trip_length = $('#edit-trip-length input:checked').val();
			var trip_popularity_scale = $('#edit-trip-popularity-scale input:checked').val();
			var trip_activities = $('#edit-trip-activities input:checked').val();
			var param = 'trip_seasons=' + trip_seasons + '&trip_length=' + trip_length + '&trip_popularity_scale=' + trip_popularity_scale + '&trip_activities=' + trip_activities;
			
			var url = location.protocol + '//' + location.host + Drupal.settings.basePath + 'guru_tools_survey_form/ajax_callback_getid?' + param;
			// console.log(url);
			// return false;
			
			$.ajax({
				url: url,
				dataType:'json',
				async: false,
				success: function(data) {
					console.log(url);
					console.log(data);
					return false;
					//$('.offer-submit .recurring-loading').css('display','none');
					//$('#edit-add-blades').show();
					//$('#edit-select-your-blades-wrapper').show();
					//$('#replace-package-select-error-div').empty();
					// Change site name to current user name.
					//$('.subscription-result-summary').html('<div class="subscription-success-message">You choose package:' + frequency + '</div>');
				}
			});			
		}); */
	}

    $("body" ).delegate( "#edit-survey-save", "click", function(e) {

        $('.multipage-panes .messages').remove();
        $('.multipage-panes').append('<div class="messages"></div>');
        $('.multipage-panes .messages').hide()

        var currentElem = $(this).parents('form').find('.multipage-panes .current');
        var isCheckedLen =  currentElem.find("input:checked").length;

        if (isCheckedLen == 0){
            $('.multipage-panes .messages').show().addClass('error');
            $('.multipage-panes .messages').text('Please choose an option to proceed.');
			 e.preventDefault();
            return false;
        }else{
            $('#guru-tools-survey-form').submit();
            $('#guru-tools-survey-form').attr('disabled','disabled');
        }


    });

});;
Drupal.TBMegaMenu = Drupal.TBMegaMenu || {};

(function ($) {
  Drupal.TBMegaMenu.oldWindowWidth = 0;
  Drupal.TBMegaMenu.displayedMenuMobile = false;
  Drupal.TBMegaMenu.supportedScreens = [980];
  Drupal.TBMegaMenu.menuResponsive = function () {
    var windowWidth = window.innerWidth ? window.innerWidth : $(window).width();
    var navCollapse = $('.tb-megamenu').children('.nav-collapse');
    if (windowWidth < Drupal.TBMegaMenu.supportedScreens[0]) {
      navCollapse.addClass('collapse');
      if (Drupal.TBMegaMenu.displayedMenuMobile) {
        navCollapse.css({height: 'auto', overflow: 'visible'});
      } else {
        navCollapse.css({height: 0, overflow: 'hidden'});
      }
    } else {
      // If width of window is greater than 980 (supported screen).
      navCollapse.removeClass('collapse');
      if (navCollapse.height() <= 0) {
        navCollapse.css({height: 'auto', overflow: 'visible'});
      }
    }
  };

  Drupal.behaviors.tbMegaMenuAction = {
    attach: function(context) {
      $('.tb-megamenu-button', context).once('menuIstance', function () {
        var This = this;
        $(This).click(function() {
          if(parseInt($(this).parent().children('.nav-collapse').height())) {
            $(this).parent().children('.nav-collapse').css({height: 0, overflow: 'hidden'});
            Drupal.TBMegaMenu.displayedMenuMobile = false;
          }
          else {
            $(this).parent().children('.nav-collapse').css({height: 'auto', overflow: 'visible'});
            Drupal.TBMegaMenu.displayedMenuMobile = true;
          }
        });
      });


      var isTouch = 'ontouchstart' in window && !(/hp-tablet/gi).test(navigator.appVersion);
      if(!isTouch){
        $(document).ready(function($){
          var mm_duration = 0;
          $('.tb-megamenu').each (function(){
            if ($(this).data('duration')) {
              mm_duration = $(this).data('duration');
            }
          });
          var mm_timeout = mm_duration ? 100 + mm_duration : 500;
          $('.nav > li, li.mega').hover(function(event) {
                var $this = $(this);
                if ($this.hasClass ('mega')) {
                  $this.addClass ('animating');
                  clearTimeout ($this.data('animatingTimeout'));
                  $this.data('animatingTimeout', setTimeout(function(){$this.removeClass ('animating')}, mm_timeout));
                  clearTimeout ($this.data('hoverTimeout'));
                  $this.data('hoverTimeout', setTimeout(function(){$this.addClass ('open')}, 100));
                } else {
                  clearTimeout ($this.data('hoverTimeout'));
                  $this.data('hoverTimeout',
                      setTimeout(function(){$this.addClass ('open')}, 100));
                }
              },
              function(event) {
                var $this = $(this);
                if ($this.hasClass ('mega')) {
                  $this.addClass ('animating');
                  clearTimeout ($this.data('animatingTimeout'));
                  $this.data('animatingTimeout',
                      setTimeout(function(){$this.removeClass ('animating')}, mm_timeout));
                  clearTimeout ($this.data('hoverTimeout'));
                  $this.data('hoverTimeout', setTimeout(function(){$this.removeClass ('open')}, 100));
                } else {
                  clearTimeout ($this.data('hoverTimeout'));
                  $this.data('hoverTimeout',
                      setTimeout(function(){$this.removeClass ('open')}, 100));
                }
              });
        });
      }

      $(window).resize(function() {
        var windowWidth = window.innerWidth ? window.innerWidth : $(window).width();
        if(windowWidth != Drupal.TBMegaMenu.oldWindowWidth){
          Drupal.TBMegaMenu.oldWindowWidth = windowWidth;
          Drupal.TBMegaMenu.menuResponsive();
        }
      });
    },
  }
})(jQuery);

;
Drupal.TBMegaMenu = Drupal.TBMegaMenu || {};

(function ($) {
  Drupal.TBMegaMenu.createTouchMenu = function(items) {
      items.children('a').each( function() {
	var $item = $(this);
        var tbitem = $(this).parent();
        $item.click( function(event){
          if ($item.hasClass('tb-megamenu-clicked')) {
            var $uri = $item.attr('href');
            window.location.href = $uri;
          }
          else {
            event.preventDefault();
            $item.addClass('tb-megamenu-clicked');
            if(!tbitem.hasClass('open')){	
              tbitem.addClass('open');
            }
          }
        }).closest('li').mouseleave( function(){
          $item.removeClass('tb-megamenu-clicked');
          tbitem.removeClass('open');
        });
     });
     /*
     items.children('a').children('span.caret').each( function() {
	var $item = $(this).parent();
        $item.click(function(event){
          tbitem = $item.parent();
          if ($item.hasClass('tb-megamenu-clicked')) {
            Drupal.TBMegaMenu.eventStopPropagation(event);
            if(tbitem.hasClass('open')){	
              tbitem.removeClass('open');
              $item.removeClass('tb-megamenu-clicked');
            }
          }
          else {
            Drupal.TBMegaMenu.eventStopPropagation(event);
            $item.addClass('tb-megamenu-clicked');
            if(!tbitem.hasClass('open')){	
              tbitem.addClass('open');
              $item.removeClass('tb-megamenu-clicked');
            }
          }
        });
     });
     */
  }
  
  Drupal.TBMegaMenu.eventStopPropagation = function(event) {
    if (event.stopPropagation) {
      event.stopPropagation();
    }
    else if (window.event) {
      window.event.cancelBubble = true;
    }
  }  
  Drupal.behaviors.tbMegaMenuTouchAction = {
    attach: function(context) {
      var isTouch = 'ontouchstart' in window && !(/hp-tablet/gi).test(navigator.appVersion);
      if(isTouch){
        $('html').addClass('touch');
        Drupal.TBMegaMenu.createTouchMenu($('.tb-megamenu ul.nav li.mega').has('.dropdown-menu'));
      }
    }
  }
})(jQuery);
;
/**
 * jQuery Plugin to obtain touch gestures from iPhone, iPod Touch and iPad, should also work with Android mobile phones (not tested yet!)
 * Common usage: wipe images (left and right to show the previous or next image)
 * 
 * @author Andreas Waltl, netCU Internetagentur (http://www.netcu.de)
 * @version 1.1.1 (9th December 2010) - fix bug (older IE's had problems)
 * @version 1.1 (1st September 2010) - support wipe up and wipe down
 * @version 1.0 (15th July 2010)
 */
(function ($) {
    $.fn.touchwipe = function (settings) {
        var config = {
            min_move_x: 20,
            min_move_y: 20,
            wipeLeft: function () {},
            wipeRight: function () {},
            wipeUp: function () {},
            wipeDown: function () {},
            preventDefaultEvents: true
        };
        if (settings) $.extend(config, settings);
        this.each(function () {
            var startX;
            var startY;
            var isMoving = false;

            function cancelTouch() {
                this.removeEventListener('touchmove', onTouchMove);
                startX = null;
                isMoving = false
            }
            function onTouchMove(e) {
                if (config.preventDefaultEvents) {
                    e.preventDefault()
                }
                if (isMoving) {
                    var x = e.touches[0].pageX;
                    var y = e.touches[0].pageY;
                    var dx = startX - x;
                    var dy = startY - y;
                    if (Math.abs(dx) >= config.min_move_x) {
                        cancelTouch();
                        if (dx > 0) {
                            config.wipeLeft()
                        } else {
                            config.wipeRight()
                        }
                    } else if (Math.abs(dy) >= config.min_move_y) {
                        cancelTouch();
                        if (dy > 0) {
                            config.wipeDown()
                        } else {
                            config.wipeUp()
                        }
                    }
                }
            }
            function onTouchStart(e) {
                if (e.touches.length == 1) {
                    startX = e.touches[0].pageX;
                    startY = e.touches[0].pageY;
                    isMoving = true;
                    this.addEventListener('touchmove', onTouchMove, false)
                }
            }
            if ('ontouchstart' in document.documentElement) {
                this.addEventListener('touchstart', onTouchStart, false)
            }
        });
        return this
    }
})(jQuery);;
/* Modernizr 2.6.2 (Custom Build) | MIT & BSD
 * Build: http://modernizr.com/download/#-csstransforms3d-csstransitions-touch-shiv-cssclasses-prefixed-teststyles-testprop-testallprops-prefixes-domprefixes-load
 */
;window.Modernizr=function(a,b,c){function z(a){j.cssText=a}function A(a,b){return z(m.join(a+";")+(b||""))}function B(a,b){return typeof a===b}function C(a,b){return!!~(""+a).indexOf(b)}function D(a,b){for(var d in a){var e=a[d];if(!C(e,"-")&&j[e]!==c)return b=="pfx"?e:!0}return!1}function E(a,b,d){for(var e in a){var f=b[a[e]];if(f!==c)return d===!1?a[e]:B(f,"function")?f.bind(d||b):f}return!1}function F(a,b,c){var d=a.charAt(0).toUpperCase()+a.slice(1),e=(a+" "+o.join(d+" ")+d).split(" ");return B(b,"string")||B(b,"undefined")?D(e,b):(e=(a+" "+p.join(d+" ")+d).split(" "),E(e,b,c))}var d="2.6.2",e={},f=!0,g=b.documentElement,h="modernizr",i=b.createElement(h),j=i.style,k,l={}.toString,m=" -webkit- -moz- -o- -ms- ".split(" "),n="Webkit Moz O ms",o=n.split(" "),p=n.toLowerCase().split(" "),q={},r={},s={},t=[],u=t.slice,v,w=function(a,c,d,e){var f,i,j,k,l=b.createElement("div"),m=b.body,n=m||b.createElement("body");if(parseInt(d,10))while(d--)j=b.createElement("div"),j.id=e?e[d]:h+(d+1),l.appendChild(j);return f=["&#173;",'<style id="s',h,'">',a,"</style>"].join(""),l.id=h,(m?l:n).innerHTML+=f,n.appendChild(l),m||(n.style.background="",n.style.overflow="hidden",k=g.style.overflow,g.style.overflow="hidden",g.appendChild(n)),i=c(l,a),m?l.parentNode.removeChild(l):(n.parentNode.removeChild(n),g.style.overflow=k),!!i},x={}.hasOwnProperty,y;!B(x,"undefined")&&!B(x.call,"undefined")?y=function(a,b){return x.call(a,b)}:y=function(a,b){return b in a&&B(a.constructor.prototype[b],"undefined")},Function.prototype.bind||(Function.prototype.bind=function(b){var c=this;if(typeof c!="function")throw new TypeError;var d=u.call(arguments,1),e=function(){if(this instanceof e){var a=function(){};a.prototype=c.prototype;var f=new a,g=c.apply(f,d.concat(u.call(arguments)));return Object(g)===g?g:f}return c.apply(b,d.concat(u.call(arguments)))};return e}),q.touch=function(){var c;return"ontouchstart"in a||a.DocumentTouch&&b instanceof DocumentTouch?c=!0:w(["@media (",m.join("touch-enabled),("),h,")","{#modernizr{top:9px;position:absolute}}"].join(""),function(a){c=a.offsetTop===9}),c},q.csstransforms3d=function(){var a=!!F("perspective");return a&&"webkitPerspective"in g.style&&w("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}",function(b,c){a=b.offsetLeft===9&&b.offsetHeight===3}),a},q.csstransitions=function(){return F("transition")};for(var G in q)y(q,G)&&(v=G.toLowerCase(),e[v]=q[G](),t.push((e[v]?"":"no-")+v));return e.addTest=function(a,b){if(typeof a=="object")for(var d in a)y(a,d)&&e.addTest(d,a[d]);else{a=a.toLowerCase();if(e[a]!==c)return e;b=typeof b=="function"?b():b,typeof f!="undefined"&&f&&(g.className+=" "+(b?"":"no-")+a),e[a]=b}return e},z(""),i=k=null,function(a,b){function k(a,b){var c=a.createElement("p"),d=a.getElementsByTagName("head")[0]||a.documentElement;return c.innerHTML="x<style>"+b+"</style>",d.insertBefore(c.lastChild,d.firstChild)}function l(){var a=r.elements;return typeof a=="string"?a.split(" "):a}function m(a){var b=i[a[g]];return b||(b={},h++,a[g]=h,i[h]=b),b}function n(a,c,f){c||(c=b);if(j)return c.createElement(a);f||(f=m(c));var g;return f.cache[a]?g=f.cache[a].cloneNode():e.test(a)?g=(f.cache[a]=f.createElem(a)).cloneNode():g=f.createElem(a),g.canHaveChildren&&!d.test(a)?f.frag.appendChild(g):g}function o(a,c){a||(a=b);if(j)return a.createDocumentFragment();c=c||m(a);var d=c.frag.cloneNode(),e=0,f=l(),g=f.length;for(;e<g;e++)d.createElement(f[e]);return d}function p(a,b){b.cache||(b.cache={},b.createElem=a.createElement,b.createFrag=a.createDocumentFragment,b.frag=b.createFrag()),a.createElement=function(c){return r.shivMethods?n(c,a,b):b.createElem(c)},a.createDocumentFragment=Function("h,f","return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&("+l().join().replace(/\w+/g,function(a){return b.createElem(a),b.frag.createElement(a),'c("'+a+'")'})+");return n}")(r,b.frag)}function q(a){a||(a=b);var c=m(a);return r.shivCSS&&!f&&!c.hasCSS&&(c.hasCSS=!!k(a,"article,aside,figcaption,figure,footer,header,hgroup,nav,section{display:block}mark{background:#FF0;color:#000}")),j||p(a,c),a}var c=a.html5||{},d=/^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,e=/^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,f,g="_html5shiv",h=0,i={},j;(function(){try{var a=b.createElement("a");a.innerHTML="<xyz></xyz>",f="hidden"in a,j=a.childNodes.length==1||function(){b.createElement("a");var a=b.createDocumentFragment();return typeof a.cloneNode=="undefined"||typeof a.createDocumentFragment=="undefined"||typeof a.createElement=="undefined"}()}catch(c){f=!0,j=!0}})();var r={elements:c.elements||"abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",shivCSS:c.shivCSS!==!1,supportsUnknownElements:j,shivMethods:c.shivMethods!==!1,type:"default",shivDocument:q,createElement:n,createDocumentFragment:o};a.html5=r,q(b)}(this,b),e._version=d,e._prefixes=m,e._domPrefixes=p,e._cssomPrefixes=o,e.testProp=function(a){return D([a])},e.testAllProps=F,e.testStyles=w,e.prefixed=function(a,b,c){return b?F(a,b,c):F(a,"pfx")},g.className=g.className.replace(/(^|\s)no-js(\s|$)/,"$1$2")+(f?" js "+t.join(" "):""),e}(this,this.document),function(a,b,c){function d(a){return"[object Function]"==o.call(a)}function e(a){return"string"==typeof a}function f(){}function g(a){return!a||"loaded"==a||"complete"==a||"uninitialized"==a}function h(){var a=p.shift();q=1,a?a.t?m(function(){("c"==a.t?B.injectCss:B.injectJs)(a.s,0,a.a,a.x,a.e,1)},0):(a(),h()):q=0}function i(a,c,d,e,f,i,j){function k(b){if(!o&&g(l.readyState)&&(u.r=o=1,!q&&h(),l.onload=l.onreadystatechange=null,b)){"img"!=a&&m(function(){t.removeChild(l)},50);for(var d in y[c])y[c].hasOwnProperty(d)&&y[c][d].onload()}}var j=j||B.errorTimeout,l=b.createElement(a),o=0,r=0,u={t:d,s:c,e:f,a:i,x:j};1===y[c]&&(r=1,y[c]=[]),"object"==a?l.data=c:(l.src=c,l.type=a),l.width=l.height="0",l.onerror=l.onload=l.onreadystatechange=function(){k.call(this,r)},p.splice(e,0,u),"img"!=a&&(r||2===y[c]?(t.insertBefore(l,s?null:n),m(k,j)):y[c].push(l))}function j(a,b,c,d,f){return q=0,b=b||"j",e(a)?i("c"==b?v:u,a,b,this.i++,c,d,f):(p.splice(this.i++,0,a),1==p.length&&h()),this}function k(){var a=B;return a.loader={load:j,i:0},a}var l=b.documentElement,m=a.setTimeout,n=b.getElementsByTagName("script")[0],o={}.toString,p=[],q=0,r="MozAppearance"in l.style,s=r&&!!b.createRange().compareNode,t=s?l:n.parentNode,l=a.opera&&"[object Opera]"==o.call(a.opera),l=!!b.attachEvent&&!l,u=r?"object":l?"script":"img",v=l?"script":u,w=Array.isArray||function(a){return"[object Array]"==o.call(a)},x=[],y={},z={timeout:function(a,b){return b.length&&(a.timeout=b[0]),a}},A,B;B=function(a){function b(a){var a=a.split("!"),b=x.length,c=a.pop(),d=a.length,c={url:c,origUrl:c,prefixes:a},e,f,g;for(f=0;f<d;f++)g=a[f].split("="),(e=z[g.shift()])&&(c=e(c,g));for(f=0;f<b;f++)c=x[f](c);return c}function g(a,e,f,g,h){var i=b(a),j=i.autoCallback;i.url.split(".").pop().split("?").shift(),i.bypass||(e&&(e=d(e)?e:e[a]||e[g]||e[a.split("index.html").pop().split("?")[0]]),i.instead?i.instead(a,e,f,g,h):(y[i.url]?i.noexec=!0:y[i.url]=1,f.load(i.url,i.forceCSS||!i.forceJS&&"css"==i.url.split(".").pop().split("?").shift()?"c":c,i.noexec,i.attrs,i.timeout),(d(e)||d(j))&&f.load(function(){k(),e&&e(i.origUrl,h,g),j&&j(i.origUrl,h,g),y[i.url]=2})))}function h(a,b){function c(a,c){if(a){if(e(a))c||(j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}),g(a,j,b,0,h);else if(Object(a)===a)for(n in m=function(){var b=0,c;for(c in a)a.hasOwnProperty(c)&&b++;return b}(),a)a.hasOwnProperty(n)&&(!c&&!--m&&(d(j)?j=function(){var a=[].slice.call(arguments);k.apply(this,a),l()}:j[n]=function(a){return function(){var b=[].slice.call(arguments);a&&a.apply(this,b),l()}}(k[n])),g(a[n],j,b,n,h))}else!c&&l()}var h=!!a.test,i=a.load||a.both,j=a.callback||f,k=j,l=a.complete||f,m,n;c(h?a.yep:a.nope,!!i),i&&c(i)}var i,j,l=this.yepnope.loader;if(e(a))g(a,0,l,0);else if(w(a))for(i=0;i<a.length;i++)j=a[i],e(j)?g(j,0,l,0):w(j)?B(j):Object(j)===j&&h(j,l);else Object(a)===a&&h(a,l)},B.addPrefix=function(a,b){z[a]=b},B.addFilter=function(a){x.push(a)},B.errorTimeout=1e4,null==b.readyState&&b.addEventListener&&(b.readyState="loading",b.addEventListener("DOMContentLoaded",A=function(){b.removeEventListener("DOMContentLoaded",A,0),b.readyState="complete"},0)),a.yepnope=k(),a.yepnope.executeStack=h,a.yepnope.injectJs=function(a,c,d,e,i,j){var k=b.createElement("script"),l,o,e=e||B.errorTimeout;k.src=a;for(o in d)k.setAttribute(o,d[o]);c=j?h:c||f,k.onreadystatechange=k.onload=function(){!l&&g(k.readyState)&&(l=1,c(),k.onload=k.onreadystatechange=null)},m(function(){l||(l=1,c(1))},e),i?k.onload():n.parentNode.insertBefore(k,n)},a.yepnope.injectCss=function(a,c,d,e,g,i){var e=b.createElement("link"),j,c=i?h:c||f;e.href=a,e.rel="stylesheet",e.type="text/css";for(j in d)e.setAttribute(j,d[j]);g||(n.parentNode.insertBefore(e,n),m(c,0))}}(this,document),Modernizr.load=function(){yepnope.apply(window,[].slice.call(arguments,0))};;
/*! jQuery Migrate v1.2.1 | (c) 2005, 2013 jQuery Foundation, Inc. and other contributors | jquery.org/license */
jQuery.migrateMute===void 0&&(jQuery.migrateMute=!0),function(e,t,n){function r(n){var r=t.console;i[n]||(i[n]=!0,e.migrateWarnings.push(n),r&&r.warn&&!e.migrateMute&&(r.warn("JQMIGRATE: "+n),e.migrateTrace&&r.trace&&r.trace()))}function a(t,a,i,o){if(Object.defineProperty)try{return Object.defineProperty(t,a,{configurable:!0,enumerable:!0,get:function(){return r(o),i},set:function(e){r(o),i=e}}),n}catch(s){}e._definePropertyBroken=!0,t[a]=i}var i={};e.migrateWarnings=[],!e.migrateMute&&t.console&&t.console.log&&t.console.log("JQMIGRATE: Logging is active"),e.migrateTrace===n&&(e.migrateTrace=!0),e.migrateReset=function(){i={},e.migrateWarnings.length=0},"BackCompat"===document.compatMode&&r("jQuery is not compatible with Quirks Mode");var o=e("<input/>",{size:1}).attr("size")&&e.attrFn,s=e.attr,u=e.attrHooks.value&&e.attrHooks.value.get||function(){return null},c=e.attrHooks.value&&e.attrHooks.value.set||function(){return n},l=/^(?:input|button)$/i,d=/^[238]$/,p=/^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i,f=/^(?:checked|selected)$/i;a(e,"attrFn",o||{},"jQuery.attrFn is deprecated"),e.attr=function(t,a,i,u){var c=a.toLowerCase(),g=t&&t.nodeType;return u&&(4>s.length&&r("jQuery.fn.attr( props, pass ) is deprecated"),t&&!d.test(g)&&(o?a in o:e.isFunction(e.fn[a])))?e(t)[a](i):("type"===a&&i!==n&&l.test(t.nodeName)&&t.parentNode&&r("Can't change the 'type' of an input or button in IE 6/7/8"),!e.attrHooks[c]&&p.test(c)&&(e.attrHooks[c]={get:function(t,r){var a,i=e.prop(t,r);return i===!0||"boolean"!=typeof i&&(a=t.getAttributeNode(r))&&a.nodeValue!==!1?r.toLowerCase():n},set:function(t,n,r){var a;return n===!1?e.removeAttr(t,r):(a=e.propFix[r]||r,a in t&&(t[a]=!0),t.setAttribute(r,r.toLowerCase())),r}},f.test(c)&&r("jQuery.fn.attr('"+c+"') may use property instead of attribute")),s.call(e,t,a,i))},e.attrHooks.value={get:function(e,t){var n=(e.nodeName||"").toLowerCase();return"button"===n?u.apply(this,arguments):("input"!==n&&"option"!==n&&r("jQuery.fn.attr('value') no longer gets properties"),t in e?e.value:null)},set:function(e,t){var a=(e.nodeName||"").toLowerCase();return"button"===a?c.apply(this,arguments):("input"!==a&&"option"!==a&&r("jQuery.fn.attr('value', val) no longer sets properties"),e.value=t,n)}};var g,h,v=e.fn.init,m=e.parseJSON,y=/^([^<]*)(<[\w\W]+>)([^>]*)$/;e.fn.init=function(t,n,a){var i;return t&&"string"==typeof t&&!e.isPlainObject(n)&&(i=y.exec(e.trim(t)))&&i[0]&&("<"!==t.charAt(0)&&r("$(html) HTML strings must start with '<' character"),i[3]&&r("$(html) HTML text after last tag is ignored"),"#"===i[0].charAt(0)&&(r("HTML string cannot start with a '#' character"),e.error("JQMIGRATE: Invalid selector string (XSS)")),n&&n.context&&(n=n.context),e.parseHTML)?v.call(this,e.parseHTML(i[2],n,!0),n,a):v.apply(this,arguments)},e.fn.init.prototype=e.fn,e.parseJSON=function(e){return e||null===e?m.apply(this,arguments):(r("jQuery.parseJSON requires a valid JSON string"),null)},e.uaMatch=function(e){e=e.toLowerCase();var t=/(chrome)[ \/]([\w.]+)/.exec(e)||/(webkit)[ \/]([\w.]+)/.exec(e)||/(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e)||/(msie) ([\w.]+)/.exec(e)||0>e.indexOf("compatible")&&/(mozilla)(?:.*? rv:([\w.]+)|)/.exec(e)||[];return{browser:t[1]||"",version:t[2]||"0"}},e.browser||(g=e.uaMatch(navigator.userAgent),h={},g.browser&&(h[g.browser]=!0,h.version=g.version),h.chrome?h.webkit=!0:h.webkit&&(h.safari=!0),e.browser=h),a(e,"browser",e.browser,"jQuery.browser is deprecated"),e.sub=function(){function t(e,n){return new t.fn.init(e,n)}e.extend(!0,t,this),t.superclass=this,t.fn=t.prototype=this(),t.fn.constructor=t,t.sub=this.sub,t.fn.init=function(r,a){return a&&a instanceof e&&!(a instanceof t)&&(a=t(a)),e.fn.init.call(this,r,a,n)},t.fn.init.prototype=t.fn;var n=t(document);return r("jQuery.sub() is deprecated"),t},e.ajaxSetup({converters:{"text json":e.parseJSON}});var b=e.fn.data;e.fn.data=function(t){var a,i,o=this[0];return!o||"events"!==t||1!==arguments.length||(a=e.data(o,t),i=e._data(o,t),a!==n&&a!==i||i===n)?b.apply(this,arguments):(r("Use of jQuery.fn.data('events') is deprecated"),i)};var j=/\/(java|ecma)script/i,w=e.fn.andSelf||e.fn.addBack;e.fn.andSelf=function(){return r("jQuery.fn.andSelf() replaced by jQuery.fn.addBack()"),w.apply(this,arguments)},e.clean||(e.clean=function(t,a,i,o){a=a||document,a=!a.nodeType&&a[0]||a,a=a.ownerDocument||a,r("jQuery.clean() is deprecated");var s,u,c,l,d=[];if(e.merge(d,e.buildFragment(t,a).childNodes),i)for(c=function(e){return!e.type||j.test(e.type)?o?o.push(e.parentNode?e.parentNode.removeChild(e):e):i.appendChild(e):n},s=0;null!=(u=d[s]);s++)e.nodeName(u,"script")&&c(u)||(i.appendChild(u),u.getElementsByTagName!==n&&(l=e.grep(e.merge([],u.getElementsByTagName("script")),c),d.splice.apply(d,[s+1,0].concat(l)),s+=l.length));return d});var Q=e.event.add,x=e.event.remove,k=e.event.trigger,N=e.fn.toggle,T=e.fn.live,M=e.fn.die,S="ajaxStart|ajaxStop|ajaxSend|ajaxComplete|ajaxError|ajaxSuccess",C=RegExp("\\b(?:"+S+")\\b"),H=/(?:^|\s)hover(\.\S+|)\b/,A=function(t){return"string"!=typeof t||e.event.special.hover?t:(H.test(t)&&r("'hover' pseudo-event is deprecated, use 'mouseenter mouseleave'"),t&&t.replace(H,"mouseenter$1 mouseleave$1"))};e.event.props&&"attrChange"!==e.event.props[0]&&e.event.props.unshift("attrChange","attrName","relatedNode","srcElement"),e.event.dispatch&&a(e.event,"handle",e.event.dispatch,"jQuery.event.handle is undocumented and deprecated"),e.event.add=function(e,t,n,a,i){e!==document&&C.test(t)&&r("AJAX events should be attached to document: "+t),Q.call(this,e,A(t||""),n,a,i)},e.event.remove=function(e,t,n,r,a){x.call(this,e,A(t)||"",n,r,a)},e.fn.error=function(){var e=Array.prototype.slice.call(arguments,0);return r("jQuery.fn.error() is deprecated"),e.splice(0,0,"error"),arguments.length?this.bind.apply(this,e):(this.triggerHandler.apply(this,e),this)},e.fn.toggle=function(t,n){if(!e.isFunction(t)||!e.isFunction(n))return N.apply(this,arguments);r("jQuery.fn.toggle(handler, handler...) is deprecated");var a=arguments,i=t.guid||e.guid++,o=0,s=function(n){var r=(e._data(this,"lastToggle"+t.guid)||0)%o;return e._data(this,"lastToggle"+t.guid,r+1),n.preventDefault(),a[r].apply(this,arguments)||!1};for(s.guid=i;a.length>o;)a[o++].guid=i;return this.click(s)},e.fn.live=function(t,n,a){return r("jQuery.fn.live() is deprecated"),T?T.apply(this,arguments):(e(this.context).on(t,this.selector,n,a),this)},e.fn.die=function(t,n){return r("jQuery.fn.die() is deprecated"),M?M.apply(this,arguments):(e(this.context).off(t,this.selector||"**",n),this)},e.event.trigger=function(e,t,n,a){return n||C.test(e)||r("Global events are undocumented and deprecated"),k.call(this,e,t,n||document,a)},e.each(S.split("|"),function(t,n){e.event.special[n]={setup:function(){var t=this;return t!==document&&(e.event.add(document,n+"."+e.guid,function(){e.event.trigger(n,null,t,!0)}),e._data(this,n,e.guid++)),!1},teardown:function(){return this!==document&&e.event.remove(document,n+"."+e._data(this,n)),!1}}})}(jQuery,window);;
/*
 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
 *
 * Uses the built in easing capabilities added In jQuery 1.1
 * to offer multiple easing options
 *
 * TERMS OF USE - jQuery Easing
 * 
 * Open source under the BSD License. 
 * 
 * Copyright © 2008 George McGinley Smith
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of 
 * conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list 
 * of conditions and the following disclaimer in the documentation and/or other materials 
 * provided with the distribution.
 * 
 * Neither the name of the author nor the names of contributors may be used to endorse 
 * or promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE. 
 *
*/

// t: current time, b: begInnIng value, c: change In value, d: duration
jQuery.easing["jswing"]=jQuery.easing["swing"];jQuery.extend(jQuery.easing,{def:"easeOutQuad",swing:function(a,b,c,d,e){return jQuery.easing[jQuery.easing.def](a,b,c,d,e)},easeInQuad:function(a,b,c,d,e){return d*(b/=e)*b+c},easeOutQuad:function(a,b,c,d,e){return-d*(b/=e)*(b-2)+c},easeInOutQuad:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b+c;return-d/2*(--b*(b-2)-1)+c},easeInCubic:function(a,b,c,d,e){return d*(b/=e)*b*b+c},easeOutCubic:function(a,b,c,d,e){return d*((b=b/e-1)*b*b+1)+c},easeInOutCubic:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b+c;return d/2*((b-=2)*b*b+2)+c},easeInQuart:function(a,b,c,d,e){return d*(b/=e)*b*b*b+c},easeOutQuart:function(a,b,c,d,e){return-d*((b=b/e-1)*b*b*b-1)+c},easeInOutQuart:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b*b+c;return-d/2*((b-=2)*b*b*b-2)+c},easeInQuint:function(a,b,c,d,e){return d*(b/=e)*b*b*b*b+c},easeOutQuint:function(a,b,c,d,e){return d*((b=b/e-1)*b*b*b*b+1)+c},easeInOutQuint:function(a,b,c,d,e){if((b/=e/2)<1)return d/2*b*b*b*b*b+c;return d/2*((b-=2)*b*b*b*b+2)+c},easeInSine:function(a,b,c,d,e){return-d*Math.cos(b/e*(Math.PI/2))+d+c},easeOutSine:function(a,b,c,d,e){return d*Math.sin(b/e*(Math.PI/2))+c},easeInOutSine:function(a,b,c,d,e){return-d/2*(Math.cos(Math.PI*b/e)-1)+c},easeInExpo:function(a,b,c,d,e){return b==0?c:d*Math.pow(2,10*(b/e-1))+c},easeOutExpo:function(a,b,c,d,e){return b==e?c+d:d*(-Math.pow(2,-10*b/e)+1)+c},easeInOutExpo:function(a,b,c,d,e){if(b==0)return c;if(b==e)return c+d;if((b/=e/2)<1)return d/2*Math.pow(2,10*(b-1))+c;return d/2*(-Math.pow(2,-10*--b)+2)+c},easeInCirc:function(a,b,c,d,e){return-d*(Math.sqrt(1-(b/=e)*b)-1)+c},easeOutCirc:function(a,b,c,d,e){return d*Math.sqrt(1-(b=b/e-1)*b)+c},easeInOutCirc:function(a,b,c,d,e){if((b/=e/2)<1)return-d/2*(Math.sqrt(1-b*b)-1)+c;return d/2*(Math.sqrt(1-(b-=2)*b)+1)+c},easeInElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e)==1)return c+d;if(!g)g=e*.3;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return-(h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g))+c},easeOutElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e)==1)return c+d;if(!g)g=e*.3;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);return h*Math.pow(2,-10*b)*Math.sin((b*e-f)*2*Math.PI/g)+d+c},easeInOutElastic:function(a,b,c,d,e){var f=1.70158;var g=0;var h=d;if(b==0)return c;if((b/=e/2)==2)return c+d;if(!g)g=e*.3*1.5;if(h<Math.abs(d)){h=d;var f=g/4}else var f=g/(2*Math.PI)*Math.asin(d/h);if(b<1)return-.5*h*Math.pow(2,10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)+c;return h*Math.pow(2,-10*(b-=1))*Math.sin((b*e-f)*2*Math.PI/g)*.5+d+c},easeInBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;return d*(b/=e)*b*((f+1)*b-f)+c},easeOutBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;return d*((b=b/e-1)*b*((f+1)*b+f)+1)+c},easeInOutBack:function(a,b,c,d,e,f){if(f==undefined)f=1.70158;if((b/=e/2)<1)return d/2*b*b*(((f*=1.525)+1)*b-f)+c;return d/2*((b-=2)*b*(((f*=1.525)+1)*b+f)+2)+c},easeInBounce:function(a,b,c,d,e){return d-jQuery.easing.easeOutBounce(a,e-b,0,d,e)+c},easeOutBounce:function(a,b,c,d,e){if((b/=e)<1/2.75){return d*7.5625*b*b+c}else if(b<2/2.75){return d*(7.5625*(b-=1.5/2.75)*b+.75)+c}else if(b<2.5/2.75){return d*(7.5625*(b-=2.25/2.75)*b+.9375)+c}else{return d*(7.5625*(b-=2.625/2.75)*b+.984375)+c}},easeInOutBounce:function(a,b,c,d,e){if(b<e/2)return jQuery.easing.easeInBounce(a,b*2,0,d,e)*.5+c;return jQuery.easing.easeOutBounce(a,b*2-e,0,d,e)*.5+d*.5+c}})
/*
 *
 * TERMS OF USE - EASING EQUATIONS
 * 
 * Open source under the BSD License. 
 * 
 * Copyright © 2001 Robert Penner
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 * 
 * Redistributions of source code must retain the above copyright notice, this list of 
 * conditions and the following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list 
 * of conditions and the following disclaimer in the documentation and/or other materials 
 * provided with the distribution.
 * 
 * Neither the name of the author nor the names of contributors may be used to endorse 
 * or promote products derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY 
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 *  GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 *  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH DAMAGE. 
 *
 */;
!function(t){effectsIn=["bounceIn","bounceInDown","bounceInUp","bounceInLeft","bounceInRight","fadeIn","fadeInUp","fadeInDown","fadeInLeft","fadeInRight","fadeInUpBig","fadeInDownBig","fadeInLeftBig","fadeInRightBig","flipInX","flipInY","foolishIn","lightSpeedIn","rollIn","rotateIn","rotateInDownLeft","rotateInDownRight","rotateInUpLeft","rotateInUpRight","twisterInDown","twisterInUp","swap","swashIn","tinRightIn","tinLeftIn","tinUpIn","tinDownIn"],effectsOut=["bombRightOut","bombLeftOut","bounceOut","bounceOutDown","bounceOutUp","bounceOutLeft","bounceOutRight","fadeOut","fadeOutUp","fadeOutDown","fadeOutLeft","fadeOutRight","fadeOutUpBig","fadeOutDownBig","fadeOutLeftBig","fadeOutRightBig","flipOutX","flipOutY","foolishOut","hinge","holeOut","lightSpeedOut","puffOut","rollOut","rotateOut","rotateOutDownLeft","rotateOutDownRight","rotateOutUpLeft","rotateOutUpRight","rotateDown","rotateUp","rotateLeft","rotateRight","swashOut","tinRightOut","tinLeftOut","tinUpOut","tinDownOut","vanishOut"];var i=effectsIn.length,e=effectsOut.length;t.fn.mdSlider=function(s){function a(){"ActiveXObject"in window&&t(".md-item-opacity",J).addClass("md-ieopacity"),J.addClass("loading-image");var i="";if(s.responsive&&(i+=" md-slide-responsive"),s.fullwidth&&(i+=" md-slide-fullwidth"),s.showBullet&&s.posBullet&&(i+=" md-slide-bullet-"+s.posBullet),!s.showBullet&&s.showThumb&&s.posThumb&&(i+=" md-slide-thumb-"+s.posThumb),J.wrap('<div class="'+s.className+i+'"><div class="md-item-wrap"></div></div>'),P=J.parent(),_=P.parent(),E=s.responsive?J.width():s.width,j=s.height,K=[],U=C(),U&&_.addClass("md-touchdevice"),J.find("."+s.itemClassName).each(function(i){Z++,K[i]=t(this),t(this).find(".md-object").each(function(){var i=t(this).data("y")?t(this).data("y"):0,e=t(this).data("x")?t(this).data("x"):0,a=t(this).data("width")?t(this).data("width"):0,n=t(this).data("height")?t(this).data("height"):0;a>0&&t(this).width(a/s.width*100+"%"),n>0&&t(this).height(n/s.height*100+"%");var o={top:i/s.height*100+"%",left:e/s.width*100+"%"};t(this).css(o)}),i>0&&t(this).hide()}),n(),o(),s.slideShow&&(ai=!0),t(".md-object",J).hide(),t(".md-video",_).size()>0)if(s.videoBox)t(".md-video",_).mdvideobox();else{var e=t('<div class="md-video-control" style="display: none"></div>');_.append(e),t(".md-video",_).click(function(){var i=t("<iframe></iframe>");i.attr("allowFullScreen","").attr("frameborder","0").css({width:"100%",height:"100%",background:"black"}),i.attr("src",t(this).attr("href"));var s=t('<a href="#" class="md-close-video" title="Close video"></a>');return s.click(function(){return e.html("").hide(),ai=!0,!1}),e.html("").append(i).append(s).show(),ai=!1,!1})}t(window).resize(function(){S()}).trigger("resize"),k();var a=!1;t(window).blur(function(){a=(new Date).getTime()}),t(window).focus(function(){if(a){var t=(new Date).getTime()-a;t>si-oi?oi=si-200:oi+=t,a=!1}})}function n(){if(s.slideShow&&s.showLoading){var i=t('<div class="loading-bar-hoz loading-bar-'+s.loadingPosition+'"><div class="br-timer-glow" style="left: -100px;"></div><div class="br-timer-bar" style="width:0px"></div></div>');_.append(i),H=t(".br-timer-bar",i),q=t(".br-timer-glow",i)}if(s.slideShow&&s.pauseOnHover&&P.hover(function(){ni=!0},function(){ni=!1}),0!=s.styleBorder){var e='<div class="border-top border-style-'+s.styleBorder+'"></div>';e+='<div class="border-bottom border-style-'+s.styleBorder+'"></div>',s.fullwidth||(e+='<div class="border-left border-style-'+s.styleBorder+'"><div class="edge-top"></div><div class="edge-bottom"></div></div>',e+='<div class="border-right border-style-'+s.styleBorder+'"><div class="edge-top"></div><div class="edge-bottom"></div></div>'),_.append(e)}if(0!=s.styleShadow){'<div class="md-shadow md-shadow-style-'+s.styleShadow+'"></div>'}if(s.showArrow&&(A=t('<div class="md-arrow"><div class="md-arrow-left"><span></span></div><div class="md-arrow-right"><span></span></div></div>'),P.append(A),t(".md-arrow-right",A).bind("click",function(){m()}),t(".md-arrow-left",A).bind("click",function(){u()})),0!=s.showBullet){Y=t('<div class="md-bullets"></div>'),_.append(Y);for(var a=0;Z>a;a++)Y.append('<div class="md-bullet"  rel="'+a+'"><a></a></div>');if(s.showThumb){for(var n=parseInt(J.data("thumb-width")),o=parseInt(J.data("thumb-height")),a=0;Z>a;a++){{var d=K[a].data("thumb"),r=K[a].data("thumb-type");K[a].data("thumb-alt")}if(d){var h;h="image"==r?t("<img />").attr("src",d).attr("alt",K[a].data("thumb-alt")).css({top:-(9+o)+"px",left:-(n/2-2)+"px",opacity:0}):t("<span></span>").attr("style",d).css({top:-(9+o)+"px",left:-(n/2-2)+"px",opacity:0}),t("div.md-bullet:eq("+a+")",Y).append(h).append('<div class="md-thumb-arrow" style="opacity: 0"></div>')}}t("div.md-bullet",Y).hover(function(){t(this).addClass("md_hover"),t("img, span",this).show().animate({opacity:1},200),t(".md-thumb-arrow",this).show().animate({opacity:1},200)},function(){t(this).removeClass("md_hover"),t("img, span",this).animate({opacity:0},200,function(){t(this).hide()}),t(".md-thumb-arrow",this).animate({opacity:0},200,function(){t(this).hide()})})}t("div.md-bullet",_).click(function(){if(t(this).hasClass("md-current"))return!1;var i=t(this).attr("rel");l(i)})}else if(s.showThumb){var c=t('<div class="md-thumb"><div class="md-thumb-container"><div class="md-thumb-items"></div></div></div>').appendTo(_);F=t(".md-thumb-items",c);for(var a=0;Z>a;a++){{var d=K[a].data("thumb"),r=K[a].data("thumb-type");K[a].data("thumb-alt")}if(d){var p=t('<a class="md-thumb-item" />').attr("rel",a);p.append("image"==r?t("<img />").attr("src",d).attr("alt",K[a].data("thumb-alt")):t("<span />").attr("style",d).css("display","inline-block")),F.append(p)}}t("a",F).click(function(){if(t(this).hasClass("md-current")||ei)return!1;var i=t(this).attr("rel");l(i)})}}function o(){U?(J.bind("touchstart",function(t){return ii?!1:(t=t.originalEvent.touches[0]||t.originalEvent.changedTouches[0],ii=!0,Q=void 0,J.mouseY=t.pageY,void(J.mouseX=t.pageX))}),J.bind("touchmove",function(t){if(t=t.originalEvent.touches[0]||t.originalEvent.changedTouches[0],ii){var i=t.pageX||t.clientX,e=t.pageY||t.clientY;return"undefined"==typeof Q&&(Q=!!(Q||Math.abs(e-J.mouseY)>Math.abs(i-J.mouseX))),Q?void(ii=!1):(N=i-J.mouseX,!1)}}),J.bind("touchend",function(){if(ii){if(ii=!1,N>s.touchSensitive)return u(),N=0,!1;if(N<-s.touchSensitive)return m(),N=0,!1}})):(P.hover(function(){A&&A.addClass("active")},function(){A&&A.removeClass("active")}),_.trigger("hover")),s.enableDrag&&(J.mousedown(function(t){return ii||(ii=!0,Q=void 0,J.mouseY=t.pageY,J.mouseX=t.pageX),!1}),J.mousemove(function(t){if(ii){var i=t.pageX||t.clientX,e=t.pageY||t.clientY;return"undefined"==typeof Q&&(Q=!!(Q||Math.abs(e-J.mouseY)>Math.abs(i-J.mouseX))),Q?void(ii=!1):(N=i-J.mouseX,!1)}}),J.mouseup(function(){return ii?(ii=!1,N>s.touchSensitive?u():N<-s.touchSensitive&&m(),N=0,!1):void 0}),J.mouseleave(function(){J.mouseup()}))}function d(){if(F){F.unbind("touchstart"),F.unbind("touchmove"),F.unbind("touchmove"),F.css("left",0);var i=0,e=F.parent().parent();if(t("a.md-thumb-item",F).each(function(){t("img",t(this)).length>0?(t("img",t(this)).css("borderLeftWidth")&&(i+=parseInt(t("img",t(this)).css("borderLeftWidth"),10)),t("img",t(this)).css("borderRightWidth")&&(i+=parseInt(t("img",t(this)).css("borderRightWidth"),10)),t("img",t(this)).css("marginLeft")&&(i+=parseInt(t("img",t(this)).css("marginLeft"),10)),t("img",t(this)).css("marginRight")&&(i+=parseInt(t("img",t(this)).css("marginRight"),10))):(t("span",t(this)).css("borderLeftWidth")&&(i+=parseInt(t("span",t(this)).css("borderLeftWidth"),10)),t("span",t(this)).css("borderRightWidth")&&(i+=parseInt(t("span",t(this)).css("borderRightWidth"),10)),t("span",t(this)).css("marginLeft")&&(i+=parseInt(t("span",t(this)).css("marginLeft"),10)),t("span",t(this)).css("marginRight")&&(i+=parseInt(t("span",t(this)).css("marginRight"),10))),t(this).css("borderLeftWidth")&&(i+=parseInt(t(this).css("borderLeftWidth"),10)),t(this).css("borderRightWidth")&&(i+=parseInt(t(this).css("borderRightWidth"),10)),t(this).css("marginLeft")&&(i+=parseInt(t(this).css("marginLeft"),10)),t(this).css("marginRight")&&(i+=parseInt(t(this).css("marginRight"),10)),i+=parseInt(J.data("thumb-width"))}),t(".md-thumb-next",e).remove(),t(".md-thumb-prev",e).remove(),i>t(".md-thumb-container",e).width()&&(ti=t(".md-thumb-container",e).width()-i,F.width(i),e.append('<div class="md-thumb-prev"></div><div class="md-thumb-next"></div>'),t(".md-thumb-prev",e).click(function(){r("right")}),t(".md-thumb-next",e).click(function(){r("left")}),h(),U)){ei=!0;var a,n;F.bind("touchstart",function(t){return t=t.originalEvent.touches[0]||t.originalEvent.changedTouches[0],a=!0,this.mouseX=t.pageX,n=F.position().left,!1}),F.bind("touchmove",function(t){return t.preventDefault(),t=t.originalEvent.touches[0]||t.originalEvent.changedTouches[0],a&&F.css("left",n+t.pageX-this.mouseX),!1}),F.bind("touchend",function(i){if(i.preventDefault(),i=i.originalEvent.touches[0]||i.originalEvent.changedTouches[0],a=!1,Math.abs(i.pageX-this.mouseX)<s.touchSensitive){var e=t(i.target).closest("a.md-thumb-item");return e.length&&l(e.attr("rel")),F.stop(!0,!0).animate({left:n},400),!1}return F.position().left<ti?F.stop(!0,!0).animate({left:ti},400,function(){h()}):F.position().left>0&&F.stop(!0,!0).animate({left:0},400,function(){h()}),n=0,!1})}}}function r(i){if(F)if("left"==i){var e=F.position().left;if(e>ti){var s=t(".md-thumb-container",_).width();e-s>ti?F.stop(!0,!0).animate({left:e-s},400,function(){h()}):F.stop(!0,!0).animate({left:ti},400,function(){h()})}}else if("right"==i){var e=F.position().left;if(0>e){var s=t(".md-thumb-container",_).width();0>e+s?F.stop(!0,!0).animate({left:e+s},400,function(){h()}):F.stop(!0,!0).animate({left:0},400,function(){h()})}}else{var a=t("a",F).index(t("a.md-current",F));if(a>=0){var e=F.position().left,n=a*t("a",F).width();if(0>n+e)F.stop(!0,!0).animate({left:-n},400,function(){h()});else{var o=n+t("a",F).width(),s=t(".md-thumb-container",_).width();o+e>s&&F.stop(!0,!0).animate({left:s-o},400,function(){h()})}}}}function h(){var i=F.position().left;i>ti?t(".md-thumb-next",_).show():t(".md-thumb-next",_).hide(),0>i?t(".md-thumb-prev",_).show():t(".md-thumb-prev",_).hide()}function l(i){if(oi=0,si=K[i].data("timeout")?K[i].data("timeout"):s.slideShowDelay,H){var e=oi*E/si;H.width(e),q.css({left:e-100+"px"})}if(z=V,V=i,s.onStartTransition.call(J),K[z]){t("div.md-bullet:eq("+z+")",Y).removeClass("md-current"),t("a:eq("+z+")",F).removeClass("md-current"),v(K[z]);var a=s.transitions;if("random"==s.transitions.toLowerCase()){var n=new Array("slit-horizontal-left-top","slit-horizontal-top-right","slit-horizontal-bottom-up","slit-vertical-down","slit-vertical-up","strip-up-right","strip-up-left","strip-down-right","strip-down-left","strip-left-up","strip-left-down","strip-right-up","strip-right-down","strip-right-left-up","strip-right-left-down","strip-up-down-right","strip-up-down-left","left-curtain","right-curtain","top-curtain","bottom-curtain","slide-in-right","slide-in-left","slide-in-up","slide-in-down","fade");a=n[Math.floor(Math.random()*(n.length+1))],void 0==a&&(a="fade"),a=t.trim(a.toLowerCase())}if(-1!=s.transitions.indexOf(",")){var n=s.transitions.split(",");a=n[Math.floor(Math.random()*n.length)],void 0==a&&(a="fade"),a=t.trim(a.toLowerCase())}if(K[V].data("transition")){var n=K[V].data("transition").split(",");a=n[Math.floor(Math.random()*n.length)],a=t.trim(a.toLowerCase())}(this.support=Modernizr.csstransitions&&Modernizr.csstransforms3d)||"slit-horizontal-left-top"!=a&&"slit-horizontal-top-right"!=a&&"slit-horizontal-bottom-up"!=a&&"slit-vertical-down"!=a&&"slit-vertical-up"!=a||(a="fade"),$=!0,O(a),Y&&t("div.md-bullet:eq("+V+")",Y).addClass("md-current"),F&&t("a:eq("+V+")",F).addClass("md-current"),r()}else K[V].css({top:0,left:0}).show(),g(K[i]),Y&&t("div.md-bullet:eq("+V+")",Y).addClass("md-current"),F&&t("a:eq("+V+")",F).addClass("md-current"),r(),$=!1}function c(){l(0),G=setInterval(p,40)}function p(){if($)return!1;if(ai&&!ni)if(oi+=40,oi>si)m();else if(H){var t=oi*E/si;H.width(t),q.css({left:t-100+"px"})}}function m(){if($)return!1;var t=V;t++,t>=Z&&s.loop?(t=0,l(t)):Z>t&&l(t)}function u(){if($)return!1;var t=V;t--,0>t&&s.loop?(t=Z-1,l(t)):t>=0&&l(t)}function f(t){var i=t.data("easeout")?t.data("easeout"):"",s=!!window.ActiveXObject&&+/msie\s(\d+)/i.exec(navigator.userAgent)[1]||0/0;s=0/0!=s?11:parseInt(s),clearTimeout(t.data("timer-start")),""!=i&&"keep"!=i&&9>=s?t.fadeOut():(t.removeClass(effectsIn.join(" ")),""!=i?("random"==i&&(i=effectsOut[Math.floor(Math.random()*e)]),t.addClass(i)):t.hide())}function v(i){i.find(".md-object").each(function(){var i=t(this);i.stop(!0,!0).hide(),clearTimeout(i.data("timer-start")),clearTimeout(i.data("timer-stop"))})}function g(e){t(".md-object",e).each(function(){var e=t(this);e.data("easeout")&&e.removeClass(effectsOut.join(" "));var s=e.data("easein")?e.data("easein"):"",a=!!window.ActiveXObject&&+/msie\s(\d+)/i.exec(navigator.userAgent)[1]||0/0;a=0/0!=a?11:parseInt(a),"random"==s&&(s=effectsIn[Math.floor(Math.random()*i)]),e.removeClass(effectsIn.join(" ")),e.hide(),void 0!=e.data("start")?e.data("timer-start",setTimeout(function(){""!=s&&9>=a?e.fadeIn():e.show().addClass(s)},e.data("start"))):e.show().addClass(s),void 0!=e.data("stop")&&e.data("timer-stop",setTimeout(function(){f(e)},e.data("stop")))})}function w(){s.onEndTransition.call(J),t(".md-strips-container",J).remove(),K[z].hide(),K[V].show(),$=!1,g(K[V])}function b(i,e){var a,e=e?e:s,n=t('<div class="md-strips-container"></div>'),o=Math.round(E/e.strips),d=Math.round(j/e.strips),r=t(".md-mainimg img",K[V]),h=t(".md-slider-overlay",K[V]);if(h.length){var l=t('<div class="md-slider-overlay"></div>');l.css({"background-color":h.css("background-color")}),n.append(l)}0==r.length&&(r=t(".md-mainimg",K[V]));for(var c=0;c<e.strips;c++){var p,m,u=i?d*c+"px":"0px",f=i?"0px":o*c+"px";c==e.strips-1?(p=i?"0px":E-o*c+"px",m=i?j-d*c+"px":"0px"):(p=i?"0px":o+"px",m=i?d+"px":"0px"),a=t('<div class="mdslider-strip"></div>').css({width:p,height:m,top:u,left:f,opacity:0}).append(r.clone().css({marginLeft:i?0:-(c*o)+"px",marginTop:i?-(c*d)+"px":0})),n.append(a)}J.append(n)}function y(i,e,s){var a,n=t('<div class="md-strips-container"></div>'),o=E/i,d=j/e,r=t(".md-mainimg img",K[s]),h=t(".md-slider-overlay",K[s]);if(h.length){var l=t('<div class="md-slider-overlay"></div>');l.css({"background-color":h.css("background-color")}),n.append(l)}0==r.length&&(r=t(".md-mainimg",K[s]));for(var c=0;e>c;c++)for(var p=0;i>p;p++){var m=d*c+"px",u=o*p+"px";a=t('<div class="mdslider-tile"/>').css({width:o,height:d,top:m,left:u}).append(r.clone().css({marginLeft:"-"+u,marginTop:"-"+m})),n.append(a)}J.append(n)}function I(){var i,e=[],s=t('<div class="md-strips-container"></div>'),a=t(".md-slider-overlay",K[V]);if(a.length){var n=t('<div class="md-slider-overlay"></div>');n.css({"background-color":a.css("background-color")}),s.append(n)}t(".md-mainimg img",K[z]),t(".md-mainimg img",K[V]),e.push(t(".md-mainimg img",K[z]).length>0?t(".md-mainimg img",K[z]):t(".md-mainimg",K[z])),e.push(t(".md-mainimg img",K[V]).length>0?t(".md-mainimg img",K[V]):t(".md-mainimg",K[V]));for(var o=0;2>o;o++)i=t('<div class="mdslider-strip"></div>').css({width:E,height:j}).append(e[o].clone()),s.append(i);J.append(s)}function x(i){var e=t('<div class="md-strips-container '+i+'"></div>'),s=t(".md-mainimg img",K[z]).length>0?t(".md-mainimg img",K[z]):t(".md-mainimg",K[z]),a=t('<div class="mdslider-slit"/>').append(s.clone()),n=t('<div class="mdslider-slit"/>'),o=s.position(),d=t(".md-slider-overlay",K[V]);if(d.length){var r=t('<div class="md-slider-overlay"></div>');r.css({"background-color":d.css("background-color")}),e.append(r)}n.append(s.clone().css("top",o.top-j/2+"px")),("slit-vertical-down"==i||"slit-vertical-up"==i)&&(n=t('<div class="mdslider-slit"/>').append(s.clone().css("left",o.left-E/2+"px"))),e.append(a).append(n),J.append(e)}function O(i){switch(i){case"slit-horizontal-left-top":case"slit-horizontal-top-right":case"slit-horizontal-bottom-up":case"slit-vertical-down":case"slit-vertical-up":x(i),t(".md-object",K[V]).hide(),K[z].hide(),K[V].show();var e=t(".mdslider-slit",J).first(),a=t(".mdslider-slit",J).last(),n={transition:"all "+s.transitionsSpeed+"ms ease-in-out","-webkit-transition":"all "+s.transitionsSpeed+"ms ease-in-out","-moz-transition":"all "+s.transitionsSpeed+"ms ease-in-out","-ms-transition":"all "+s.transitionsSpeed+"ms ease-in-out"};t(".mdslider-slit",J).css(n),setTimeout(function(){e.addClass("md-trans-elems-1"),a.addClass("md-trans-elems-2")},50),setTimeout(function(){s.onEndTransition.call(J),t(".md-strips-container",J).remove(),$=!1,g(K[V])},s.transitionsSpeed);break;case"strip-up-right":case"strip-up-left":y(s.stripCols,1,V);var o=t(".mdslider-tile",J),d=s.transitionsSpeed/s.stripCols/2,r=s.transitionsSpeed/2;"strip-up-right"==i&&(o=t(".mdslider-tile",J).reverse()),o.css({height:"1px",bottom:"0px",top:"auto"}),o.each(function(i){var e=t(this);setTimeout(function(){e.animate({height:"100%",opacity:"1.0"},r,"easeInOutQuart",function(){i==s.stripCols-1&&w()})},i*d)});break;case"strip-down-right":case"strip-down-left":y(s.stripCols,1,V);var o=t(".mdslider-tile",J),d=s.transitionsSpeed/s.stripCols/2,r=s.transitionsSpeed/2;"strip-down-right"==i&&(o=t(".mdslider-tile",J).reverse()),o.css({height:"1px",top:"0px",bottom:"auto"}),o.each(function(i){var e=t(this);setTimeout(function(){e.animate({height:"100%",opacity:"1.0"},r,"easeInOutQuart",function(){i==s.stripCols-1&&w()})},i*d)});break;case"strip-left-up":case"strip-left-down":y(1,s.stripRows,V);var o=t(".mdslider-tile",J),d=s.transitionsSpeed/s.stripRows/2,r=s.transitionsSpeed/2;"strip-left-up"==i&&(o=t(".mdslider-tile",J).reverse()),o.css({width:"1px",left:"0px",right:"auto"}),o.each(function(i){var e=t(this);setTimeout(function(){e.animate({width:"100%",opacity:"1.0"},r,"easeInOutQuart",function(){i==s.stripRows-1&&w()})},i*d)});break;case"strip-right-up":case"strip-right-down":y(1,s.stripRows,V);var o=t(".mdslider-tile",J),d=s.transitionsSpeed/s.stripRows/2,r=s.transitionsSpeed/2;"strip-left-right-up"==i&&(o=t(".mdslider-tile",J).reverse()),o.css({width:"1px",left:"auto",right:"1px"}),o.each(function(i){var e=t(this);setTimeout(function(){e.animate({width:"100%",opacity:"1.0"},r,"easeInOutQuart",function(){i==s.stripRows-1&&w()})},i*d)});break;case"strip-right-left-up":case"strip-right-left-down":y(1,s.stripRows,z),K[z].hide(),K[V].show();var o=t(".mdslider-tile",J),d=s.transitionsSpeed/s.stripRows,r=s.transitionsSpeed/2;"strip-right-left-up"==i&&(o=t(".mdslider-tile",J).reverse()),o.filter(":odd").css({width:"100%",right:"0px",left:"auto",opacity:1}).end().filter(":even").css({width:"100%",right:"auto",left:"0px",opacity:1}),o.each(function(i){var e=t(this),a=i%2==0?{left:"-50%",opacity:"0"}:{right:"-50%",opacity:"0"};setTimeout(function(){e.animate(a,r,"easeOutQuint",function(){i==s.stripRows-1&&(s.onEndTransition.call(J),t(".md-strips-container",J).remove(),$=!1,g(K[V]))})},i*d)});break;case"strip-up-down-right":case"strip-up-down-left":y(s.stripCols,1,z),K[z].hide(),K[V].show();var o=t(".mdslider-tile",J),d=s.transitionsSpeed/s.stripCols/2,r=s.transitionsSpeed/2;"strip-up-down-right"==i&&(o=t(".mdslider-tile",J).reverse()),o.filter(":odd").css({height:"100%",bottom:"0px",top:"auto",opacity:1}).end().filter(":even").css({height:"100%",bottom:"auto",top:"0px",opacity:1}),o.each(function(i){var e=t(this),a=i%2==0?{top:"-50%",opacity:0}:{bottom:"-50%",opacity:0};setTimeout(function(){e.animate(a,r,"easeOutQuint",function(){i==s.stripCols-1&&(s.onEndTransition.call(J),t(".md-strips-container",J).remove(),$=!1,g(K[V]))})},i*d)});break;case"left-curtain":y(s.stripCols,1,V);var o=t(".mdslider-tile",J),h=E/s.stripCols,d=s.transitionsSpeed/s.stripCols/2;o.each(function(i){var e=t(this);e.css({left:h*i,width:0,opacity:0}),setTimeout(function(){e.animate({width:h,opacity:"1.0"},s.transitionsSpeed/2,function(){i==s.stripCols-1&&w()})},d*i)});break;case"right-curtain":y(s.stripCols,1,V);var o=t(".mdslider-tile",J).reverse(),h=E/s.stripCols,d=s.transitionsSpeed/s.stripCols/2;o.each(function(i){var e=t(this);e.css({right:h*i,left:"auto",width:0,opacity:0}),setTimeout(function(){e.animate({width:h,opacity:"1.0"},s.transitionsSpeed/2,function(){i==s.stripCols-1&&w()})},d*i)});break;case"top-curtain":y(1,s.stripRows,V);var o=t(".mdslider-tile",J),l=j/s.stripRows,d=s.transitionsSpeed/s.stripRows/2;o.each(function(i){var e=t(this);e.css({top:l*i,height:0,opacity:0}),setTimeout(function(){e.animate({height:l,opacity:"1.0"},s.transitionsSpeed/2,function(){i==s.stripRows-1&&w()})},d*i)});break;case"bottom-curtain":y(1,s.stripRows,V);var o=t(".mdslider-tile",J).reverse(),l=j/s.stripRows,d=s.transitionsSpeed/s.stripRows/2;o.each(function(i){var e=t(this);e.css({bottom:l*i,height:0,opacity:0}),setTimeout(function(){e.animate({height:l,opacity:"1.0"},s.transitionsSpeed/2,function(){i==s.stripRows-1&&w()})},d*i)});break;case"slide-in-right":var c=0;I();var o=t(".mdslider-strip",J);o.each(function(){m=t(this);var i=c*E;m.css({left:i}),m.animate({left:i-E},s.transitionsSpeed,function(){w()}),c++});break;case"slide-in-left":var c=0;I();var o=t(".mdslider-strip",J);o.each(function(){m=t(this);var i=-c*E;m.css({left:i}),m.animate({left:E+i},2*s.transitionsSpeed,function(){w()}),c++});break;case"slide-in-up":var c=0;I();var o=t(".mdslider-strip",J);o.each(function(){m=t(this);var i=c*j;m.css({top:i}),m.animate({top:i-j},s.transitionsSpeed,function(){w()}),c++});break;case"slide-in-down":var c=0;I();var o=t(".mdslider-strip",J);o.each(function(){m=t(this);var i=-c*j;m.css({top:i}),m.animate({top:j+i},s.transitionsSpeed,function(){w()}),c++});break;case"fade":default:var p={strips:1};b(!1,p);var m=t(".mdslider-strip:first",J);m.css({height:"100%",width:E}),"slide-in-right"==i?m.css({height:"100%",width:E,left:E+"px",right:""}):"slide-in-left"==i&&m.css({left:"-"+E+"px"}),m.animate({left:"0px",opacity:1},s.transitionsSpeed,function(){w()})}}function C(){return"ontouchstart"in window||"createTouch"in document}function S(){if(_.width(),E=s.responsive?_.width():s.width,s.responsive&&(j=s.fullwidth&&E>s.width?s.height:Math.round(E/s.width*s.height)),s.responsive||s.fullwidth||_.width(E),!s.responsive&&s.fullwidth&&_.css({"min-width":E+"px"}),s.fullwidth){t(".md-objects",J).width(s.width);var i=20;(_.width()-s.width)/2>20&&(i=(_.width()-s.width)/2),_.find(".md-bullets").css({left:i,right:i}),_.find(".md-thumb").css({left:i,right:i})}s.responsive&&s.fullwidth&&_.width()<s.width&&t(".md-objects",J).width(E),_.height(j),t(".md-slide-item",J).height(j),T(),d(),B(),X(),D()}function T(){t(".md-slide-item",J).each(function(){var i=t(".md-mainimg img",this);if(1==i.length){if(i.data("defW")&&i.data("defH")){var e=i.data("defW"),s=i.data("defH");L(i,e,s)}}else t(".md-mainimg",t(this)).width(t(".md-slide-item:visible",J).width()).height(t(".md-slide-item:visible",J).height())})}function k(){var i=t(".md-slide-item .md-mainimg img",J).length;J.data("count",i),0==J.data("count")&&R(),t(".md-slide-item .md-mainimg img",J).each(function(){t(this).load(function(){var i=t(this);if(!i.data("defW")){var e=W(i.attr("src"));L(i,e.width,e.height),i.data({defW:e.width,defH:e.height})}J.data("count",J.data("count")-1),0==J.data("count")&&R()}),this.complete&&t(this).load()})}function R(){J.removeClass("loading-image"),c()}function L(i,e,s){var a=t(".md-slide-item:visible",J).width(),n=t(".md-slide-item:visible",J).height();if(s>0&&n>0)if(e/s>a/n){var o=a-n/s*e;i.css({width:"auto",height:n+"px"}),i.css(0>o?{left:o/2+"px",top:0}:{left:0,top:0})}else{var d=n-a/e*s;i.css({width:a+"px",height:"auto"}),i.css(0>d?{top:d/2+"px",left:0}:{left:0,top:0})}}function B(){var i=1;parseInt(t.browser.version,10)<9&&(i=6),t(".md-objects",J).css(_.width()<s.width?{"font-size":_.width()/s.width*100-i+"%"}:{"font-size":100-i+"%"})}function X(){t(".md-objects div.md-object",J).each(_.width()<s.width&&s.responsive?function(){var i=_.width()/s.width,e=t(this),a={};e.data("paddingtop")&&(a["padding-top"]=e.data("paddingtop")*i),e.data("paddingright")&&(a["padding-right"]=e.data("paddingright")*i),e.data("paddingbottom")&&(a["padding-bottom"]=e.data("paddingbottom")*i),e.data("paddingleft")&&(a["padding-left"]=e.data("paddingleft")*i),t("> a",e).length?t("> a",e).css(a):e.css(a)}:function(){var i=t(this),e={};i.data("paddingtop")&&(e["padding-top"]=i.data("paddingtop")),i.data("paddingtop")&&(e["padding-top"]=i.data("paddingtop")),i.data("paddingright")&&(e["padding-right"]=i.data("paddingright")),i.data("paddingbottom")&&(e["padding-bottom"]=i.data("paddingbottom")),i.data("paddingleft")&&(e["padding-left"]=i.data("paddingleft")),t("> a",i).length?t("> a",i).css(e):i.css(e)})}function D(){if(s.showThumb&&!s.showBullet){var t=J.data("thumb-height");if("1"==s.posThumb){var i=t/2;_.find(".md-thumb").css({height:t+10,bottom:-i-10}),_.css({"margin-bottom":i+10})}else _.find(".md-thumb").css({height:t+10,bottom:-(t+40)}),_.css({"margin-bottom":t+50})}}function W(t){var i=new Image;i.src=t;var e={height:i.height,width:i.width};return e}var M={className:"md-slide-wrap",itemClassName:"md-slide-item",transitions:"strip-down-left",transitionsSpeed:800,width:990,height:420,responsive:!0,fullwidth:!0,styleBorder:0,styleShadow:0,posBullet:2,posThumb:1,stripCols:20,stripRows:10,slideShowDelay:6e3,slideShow:!0,loop:!1,pauseOnHover:!1,showLoading:!0,loadingPosition:"bottom",showArrow:!0,showBullet:!0,videoBox:!1,showThumb:!0,enableDrag:!0,touchSensitive:50,onEndTransition:function(){},onStartTransition:function(){}};s=t.extend({},M,s);var z,E,j,_,P,U,A,Y,H,q,F,Q,N,G,J=t(this),K=[],V=-1,Z=0,$=!0,ti=0,ii=!1,ei=!1,si=0,ai=!1,ni=!1,oi=0;t(document).ready(function(){a()})},t.fn.reverse=[].reverse;var s=function(t,i,e){this.m_pfnPercent=i,this.m_pfnFinished=e,this.m_nLoaded=0,this.m_nProcessed=0,this.m_aImages=new Array,this.m_nICount=t.length;for(var s=0;s<t.length;s++)this.Preload(t[s])};s.prototype={Preload:function(t){var i=new Image;this.m_aImages.push(i),i.onload=s.prototype.OnLoad,i.onerror=s.prototype.OnError,i.onabort=s.prototype.OnAbort,i.oImagePreload=this,i.bLoaded=!1,i.source=t,i.src=t},OnComplete:function(){this.m_nProcessed++,this.m_nProcessed==this.m_nICount?this.m_pfnFinished():this.m_pfnPercent(Math.round(this.m_nProcessed/this.m_nICount*10))},OnLoad:function(){this.bLoaded=!0,this.oImagePreload.m_nLoaded++,this.oImagePreload.OnComplete()},OnError:function(){this.bError=!0,this.oImagePreload.OnComplete()},OnAbort:function(){this.bAbort=!0,this.oImagePreload.OnComplete()}},t.fn.mdvideobox=function(i){t(this).each(function(){function e(){if(0==t("#md-overlay").length){var i=t('<div id="md-overlay" class="md-overlay"></div>').hide().click(s),e=t('<div id="md-videocontainer" class="md-videocontainer"><div id="md-video-embed"></div><div class="md-description clearfix"><div class="md-caption"></div><a id="md-closebtn" class="md-closebtn" href="#"></a></div></div>');e.css({width:c.initialWidth+"px",height:c.initialHeight+"px",display:"none"}),t("#md-closebtn",e).click(s),t("body").append(i).append(e)}o=t("#md-overlay"),d=t("#md-videocontainer"),h=t("#md-video-embed",d),r=t(".md-caption",d),p.click(a)}function s(){return o.fadeTo("fast",0,function(){t(this).css("display","none")}),h.html(""),d.hide(),!1}function a(){c.click.call(),o.css({height:t(window).height()+"px"});var i=t(window).height()/2-c.initialHeight/2,e=t(window).width()/2-c.initialWidth/2;return d.css({top:i,left:e}).show(),h.css({background:"#fff url(css/loading.gif) no-repeat center",height:c.contentsHeight,width:c.contentsWidth}),o.css("display","block").fadeTo("fast",c.defaultOverLayFade),r.html(u),h.fadeIn("slow",function(){n()}),!1}function n(){h.css("background","#fff"),l='<iframe src="'+m+'" width="'+c.contentsWidth+'" height="'+c.contentsHeight+'" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>',h.html(l)}var o,d,r,h,l,c=t.extend({initialWidth:640,initialHeight:400,contentsWidth:640,contentsHeight:350,defaultOverLayFade:.8,click:function(){}},i),p=t(this),m=p.attr("href"),u=p.attr("title");e()})}}(jQuery);
;
